


Datas for finetuning training model for generating peptide with specific potential activity 
