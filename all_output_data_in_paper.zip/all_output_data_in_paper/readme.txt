These are the generated de novo peptide dataset for various potential activities.
